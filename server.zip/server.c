#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sqlite3.h>
#include <openssl/sha.h>
#include <openssl/rand.h>

#define PORT 8091
#define BUF_SIZE 32768
#define TOKEN_SIZE 65
static sqlite3 *db;
typedef struct { char token[TOKEN_SIZE]; int user_id; } Session;
static Session sessions[256];

static void send_response(int fd,int code,const char *type,const char *body){
 char head[512]; const char *status=code==200?"OK":code==201?"Created":code==400?"Bad Request":code==401?"Unauthorized":code==404?"Not Found":code==409?"Conflict":code==500?"Internal Server Error":"Error";
 int n=snprintf(head,sizeof(head),"HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-store\r\n\r\n",code,status,type,strlen(body));
 send(fd,head,n,0);send(fd,body,strlen(body),0);
}
static void json_error(int fd,int code,const char *msg){char b[512];snprintf(b,sizeof(b),"{\"ok\":false,\"error\":\"%s\"}",msg);send_response(fd,code,"application/json",b);}
static void db_exec(const char *sql){char *err=NULL;if(sqlite3_exec(db,sql,NULL,NULL,&err)!=SQLITE_OK){fprintf(stderr,"DB error: %s\n",err);sqlite3_free(err);}}
static void init_db(void){
 if(sqlite3_open("equilibrium.db",&db)!=SQLITE_OK){fprintf(stderr,"Cannot open database\n");exit(1);}
 sqlite3_busy_timeout(db,5000);
 db_exec("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;"
 "CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);"
 "CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,description TEXT NOT NULL,amount REAL NOT NULL,type TEXT NOT NULL,category TEXT NOT NULL,date TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);"
 "CREATE TABLE IF NOT EXISTS budgets(user_id INTEGER PRIMARY KEY,amount REAL NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);");
}
static void url_decode(char *dst,const char *src){while(*src){if(*src=='+'){*dst++=' ';src++;}else if(*src=='%'&&isxdigit((unsigned char)src[1])&&isxdigit((unsigned char)src[2])){char h[3]={src[1],src[2],0};*dst++=(char)strtol(h,NULL,16);src+=3;}else *dst++=*src++;}*dst=0;}
static void get_field(const char *body,const char *key,char *out,size_t cap){
 out[0]=0;size_t kl=strlen(key);const char *p=body;
 while(p&&*p){const char *end=strchr(p,'&');size_t len=end?(size_t)(end-p):strlen(p);const char *eq=memchr(p,'=',len);
 if(eq&&(size_t)(eq-p)==kl&&!strncmp(p,key,kl)){char tmp[4096];size_t vlen=len-(size_t)(eq-p)-1;if(vlen>=sizeof(tmp))vlen=sizeof(tmp)-1;memcpy(tmp,eq+1,vlen);tmp[vlen]=0;url_decode(tmp,tmp);snprintf(out,cap,"%s",tmp);return;}if(!end)break;p=end+1;}
}
static void sha_password(const char *salt,const char *password,char out[65]){
 char input[512],hex[65];unsigned char hash[SHA256_DIGEST_LENGTH];snprintf(input,sizeof(input),"%s:%s",salt,password);SHA256((unsigned char*)input,strlen(input),hash);
 for(int i=0;i<SHA256_DIGEST_LENGTH;i++)sprintf(hex+i*2,"%02x",hash[i]);hex[64]=0;strcpy(out,hex);
}
static void random_hex(char *out,int bytes){unsigned char b[32];if(RAND_bytes(b,bytes)!=1){for(int i=0;i<bytes;i++)b[i]=(unsigned char)(rand()%256);}for(int i=0;i<bytes;i++)sprintf(out+i*2,"%02x",b[i]);out[bytes*2]=0;}
static int get_user(const char *token){if(!token||!*token)return 0;for(int i=0;i<256;i++)if(sessions[i].user_id&&strcmp(sessions[i].token,token)==0)return sessions[i].user_id;return 0;}
static void new_session(int fd,int uid,char *token){int slot=-1;for(int i=0;i<256;i++)if(!sessions[i].user_id){slot=i;break;}if(slot<0)slot=rand()%256;random_hex(token,32);strcpy(sessions[slot].token,token);sessions[slot].user_id=uid;}
static void get_token(const char *headers,char *token){token[0]=0;const char *p=strstr(headers,"X-Session-Token:");if(!p)p=strstr(headers,"x-session-token:");if(p){p=strchr(p,':')+1;while(*p==' ')p++;size_t n=0;while(p[n]&&p[n]!='\r'&&p[n]!='\n'&&n<64)n++;memcpy(token,p,n);token[n]=0;}}
static void json_escape(const char *src,char *dst,size_t cap){
 size_t j=0;for(size_t i=0;src&&src[i]&&j+2<cap;i++){unsigned char c=(unsigned char)src[i];if(c=='"'||c=='\\'){dst[j++]='\\';dst[j++]=(char)c;}else if(c<32){if(j+6>=cap)break;snprintf(dst+j,7,"\\u%04x",c);j+=6;}else dst[j++]=(char)c;}dst[j]=0;
}
static void send_user(int fd,int uid,const char *token){sqlite3_stmt *s;sqlite3_prepare_v2(db,"SELECT name,email FROM users WHERE id=?",-1,&s,NULL);sqlite3_bind_int(s,1,uid);if(sqlite3_step(s)==SQLITE_ROW){char b[700],name[220],email[300];json_escape((const char*)sqlite3_column_text(s,0),name,sizeof(name));json_escape((const char*)sqlite3_column_text(s,1),email,sizeof(email));snprintf(b,sizeof(b),"{\"ok\":true,\"token\":\"%s\",\"user\":{\"name\":\"%s\",\"email\":\"%s\"}}",token,name,email);send_response(fd,200,"application/json",b);}else json_error(fd,401,"User not found");sqlite3_finalize(s);}
static void handle(int fd){
 char req[BUF_SIZE];int got=(int)recv(fd,req,sizeof(req)-1,0);if(got<=0)return;req[got]=0;
 char method[8]="",path[256]="";sscanf(req,"%7s %255s",method,path);
 char *body=strstr(req,"\r\n\r\n");if(body)body+=4;else body="";
 char token[65];get_token(req,token);int uid=get_user(token);
 if(!strcmp(path,"/api/register")&&!strcmp(method,"POST")){
  char name[100],email[150],pass[200],salt[65],hash[65];get_field(body,"name",name,sizeof(name));get_field(body,"email",email,sizeof(email));get_field(body,"password",pass,sizeof(pass));
  if(strlen(name)<2||strlen(email)<5||!strchr(email,'@')||strlen(pass)<8){json_error(fd,400,"Enter a name, valid email and password of at least 8 characters");return;}
  random_hex(salt,16);sha_password(salt,pass,hash);sqlite3_stmt *s;sqlite3_prepare_v2(db,"INSERT INTO users(name,email,salt,password_hash) VALUES(?,?,?,?)",-1,&s,NULL);sqlite3_bind_text(s,1,name,-1,SQLITE_TRANSIENT);sqlite3_bind_text(s,2,email,-1,SQLITE_TRANSIENT);sqlite3_bind_text(s,3,salt,-1,SQLITE_TRANSIENT);sqlite3_bind_text(s,4,hash,-1,SQLITE_TRANSIENT);int rc=sqlite3_step(s);sqlite3_finalize(s);
  if(rc!=SQLITE_DONE){json_error(fd,409,"An account with this email may already exist");return;}new_session(fd,(int)sqlite3_last_insert_rowid(db),token);send_user(fd,get_user(token),token);return;
 }
 if(!strcmp(path,"/api/login")&&!strcmp(method,"POST")){
  char email[150],pass[200],salt[65],stored[65],hash[65];get_field(body,"email",email,sizeof(email));get_field(body,"password",pass,sizeof(pass));sqlite3_stmt *s;sqlite3_prepare_v2(db,"SELECT id,salt,password_hash FROM users WHERE email=?",-1,&s,NULL);sqlite3_bind_text(s,1,email,-1,SQLITE_TRANSIENT);
  if(sqlite3_step(s)!=SQLITE_ROW){sqlite3_finalize(s);json_error(fd,401,"Incorrect email or password");return;}int id=sqlite3_column_int(s,0);snprintf(salt,sizeof(salt),"%s",sqlite3_column_text(s,1));snprintf(stored,sizeof(stored),"%s",sqlite3_column_text(s,2));sqlite3_finalize(s);sha_password(salt,pass,hash);if(strcmp(hash,stored)){json_error(fd,401,"Incorrect email or password");return;}new_session(fd,id,token);send_user(fd,id,token);return;
 }
 if(!strcmp(path,"/api/me")&&!strcmp(method,"GET")){if(!uid){json_error(fd,401,"Please sign in");return;}send_user(fd,uid,token);return;}
 if(!strcmp(path,"/api/logout")&&!strcmp(method,"POST")){for(int i=0;i<256;i++)if(sessions[i].user_id==uid&&uid&&strcmp(sessions[i].token,token)==0){sessions[i].user_id=0;sessions[i].token[0]=0;}send_response(fd,200,"application/json","{\"ok\":true}");return;}
 if(!uid){json_error(fd,401,"Please sign in again");return;}
 if(!strcmp(path,"/api/transactions")&&!strcmp(method,"GET")){
  sqlite3_stmt *s;sqlite3_prepare_v2(db,"SELECT id,description,amount,type,category,date FROM transactions WHERE user_id=? ORDER BY date DESC,id DESC",-1,&s,NULL);sqlite3_bind_int(s,1,uid);char out[24000]="{\"ok\":true,\"transactions\":[";int first=1;
  while(sqlite3_step(s)==SQLITE_ROW){if(!first)strcat(out,",");first=0;char item[1500],desc[250],type[40],cat[180],date[40];json_escape((const char*)sqlite3_column_text(s,1),desc,sizeof(desc));json_escape((const char*)sqlite3_column_text(s,3),type,sizeof(type));json_escape((const char*)sqlite3_column_text(s,4),cat,sizeof(cat));json_escape((const char*)sqlite3_column_text(s,5),date,sizeof(date));snprintf(item,sizeof(item),"{\"id\":%d,\"description\":\"%s\",\"amount\":%.2f,\"type\":\"%s\",\"category\":\"%s\",\"date\":\"%s\"}",sqlite3_column_int(s,0),desc,sqlite3_column_double(s,2),type,cat,date);if(strlen(out)+strlen(item)+4<sizeof(out))strcat(out,item);}
  strcat(out,"]}");sqlite3_finalize(s);send_response(fd,200,"application/json",out);return;
 }
 if(!strcmp(path,"/api/transactions/add")&&!strcmp(method,"POST")){
  char desc[150],amount[50],type[20],cat[80],date[20];get_field(body,"description",desc,sizeof(desc));get_field(body,"amount",amount,sizeof(amount));get_field(body,"type",type,sizeof(type));get_field(body,"category",cat,sizeof(cat));get_field(body,"date",date,sizeof(date));char *end;double val=strtod(amount,&end);
  if(!*desc||strlen(desc)>100||! *amount||*end||val<=0||val>100000000|| (strcmp(type,"income")&&strcmp(type,"expense"))||!strchr(date,'-')||strlen(date)!=10){json_error(fd,400,"Please enter valid transaction details");return;}
  sqlite3_stmt *s;sqlite3_prepare_v2(db,"INSERT INTO transactions(user_id,description,amount,type,category,date) VALUES(?,?,?,?,?,?)",-1,&s,NULL);sqlite3_bind_int(s,1,uid);sqlite3_bind_text(s,2,desc,-1,SQLITE_TRANSIENT);sqlite3_bind_double(s,3,val);sqlite3_bind_text(s,4,type,-1,SQLITE_TRANSIENT);sqlite3_bind_text(s,5,cat,-1,SQLITE_TRANSIENT);sqlite3_bind_text(s,6,date,-1,SQLITE_TRANSIENT);int rc=sqlite3_step(s);sqlite3_finalize(s);if(rc!=SQLITE_DONE){json_error(fd,500,"Could not save transaction");return;}send_response(fd,201,"application/json","{\"ok\":true}");return;
 }
 if(!strcmp(path,"/api/transactions/delete")&&!strcmp(method,"POST")){
  char idstr[30];get_field(body,"id",idstr,sizeof(idstr));int id=atoi(idstr);sqlite3_stmt *s;sqlite3_prepare_v2(db,"DELETE FROM transactions WHERE id=? AND user_id=?",-1,&s,NULL);sqlite3_bind_int(s,1,id);sqlite3_bind_int(s,2,uid);sqlite3_step(s);int changed=sqlite3_changes(db);sqlite3_finalize(s);if(!changed){json_error(fd,404,"Transaction not found");return;}send_response(fd,200,"application/json","{\"ok\":true}");return;
 }
 if(!strcmp(path,"/api/budget")&&!strcmp(method,"GET")){sqlite3_stmt *s;sqlite3_prepare_v2(db,"SELECT amount FROM budgets WHERE user_id=?",-1,&s,NULL);sqlite3_bind_int(s,1,uid);double a=sqlite3_step(s)==SQLITE_ROW?sqlite3_column_double(s,0):0;sqlite3_finalize(s);char out[100];snprintf(out,sizeof(out),"{\"ok\":true,\"amount\":%.2f}",a);send_response(fd,200,"application/json",out);return;}
 if(!strcmp(path,"/api/budget/set")&&!strcmp(method,"POST")){char a[50];get_field(body,"amount",a,sizeof(a));char *end;double val=strtod(a,&end);if(!*a||*end||val<=0||val>100000000){json_error(fd,400,"Enter a valid budget amount");return;}sqlite3_stmt *s;sqlite3_prepare_v2(db,"INSERT INTO budgets(user_id,amount) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET amount=excluded.amount",-1,&s,NULL);sqlite3_bind_int(s,1,uid);sqlite3_bind_double(s,2,val);int rc=sqlite3_step(s);sqlite3_finalize(s);if(rc!=SQLITE_DONE){json_error(fd,500,"Could not save budget");return;}send_response(fd,200,"application/json","{\"ok\":true}");return;}
 json_error(fd,404,"API route not found");
}
static void serve_static(int fd,const char *path){
 char file[512];if(!strcmp(path,"/"))snprintf(file,sizeof(file),"public/index.html");else if(strstr(path,"..")){json_error(fd,400,"Invalid path");return;}else snprintf(file,sizeof(file),"public%s",path);
 FILE *f=fopen(file,"rb");if(!f){json_error(fd,404,"File not found");return;}fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char *buf=malloc((size_t)n+1);if(!buf){fclose(f);json_error(fd,500,"Out of memory");return;}size_t r=fread(buf,1,(size_t)n,f);fclose(f);buf[r]=0;const char *type=strstr(file,".css")?"text/css":strstr(file,".js")?"application/javascript":"text/html";send_response(fd,200,type,buf);free(buf);
}
int main(void){
 signal(SIGPIPE,SIG_IGN);srand((unsigned)time(NULL));init_db();int server=socket(AF_INET,SOCK_STREAM,0);if(server<0){perror("socket");return 1;}int yes=1;setsockopt(server,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));struct sockaddr_in addr={0};addr.sin_family=AF_INET;addr.sin_addr.s_addr=INADDR_ANY;addr.sin_port=htons(PORT);if(bind(server,(struct sockaddr*)&addr,sizeof(addr))<0||listen(server,20)<0){perror("bind/listen");return 1;}printf("Equilibrium running at http://localhost:%d\n",PORT);fflush(stdout);
 while(1){int fd=accept(server,NULL,NULL);if(fd<0)continue;char peek[BUF_SIZE];int n=(int)recv(fd,peek,sizeof(peek)-1,MSG_PEEK);if(n>0){peek[n]=0;char path[256]="";sscanf(peek,"%*s %255s",path);if(strncmp(path,"/api/",5)==0)handle(fd);else serve_static(fd,path);}close(fd);}
 sqlite3_close(db);close(server);return 0;
}
